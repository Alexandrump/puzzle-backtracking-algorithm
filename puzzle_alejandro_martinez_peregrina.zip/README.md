puzzle-backtracking-algorithm



- (Optional) Install docker and run:
docker-compose up -d in the root folder.
- (Optionl) Run: docker exec -it -u www-data puzzle-php /bin/bash
- To run the script, write: php main.php and follow the steps (but it probably fails, because it isn't finished yet)
